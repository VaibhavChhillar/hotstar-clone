# Disney-plus-Hotstar-Clone-
This is Disney+ Hotstar Clone website by using HTML , CSS &amp; JavaScript .
